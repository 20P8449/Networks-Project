from pymongo import MongoClient
import hashlib
class DB:
    def __init__(self):
        self.client = MongoClient('mongodb://localhost:27017/')
        self.db = self.client['p2p-chat']

    def is_account_exist(self, username):
        return len(list(self.db.accounts.find({'username': username}))) > 0

    def register(self, username, password):
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        account = {
            "username": username,
            "password": hashed_password

        }
        self.db.accounts.insert_one(account)

    def get_password(self, username):
        return self.db.accounts.find_one({"username": username})["password"]

    def is_account_online(self, username):
        return len(list(self.db.online_peers.find({"username": username}))) > 0

    def user_login(self, username, ip, port):
        online_peer = {
            "username": username,
            "ip": ip,
            "port": port
        }
        self.db.online_peers.insert_one(online_peer)

    def user_logout(self, username):
        self.db.online_peers.remove({"username": username})

    def get_peer_ip_port(self, username):
        res = self.db.online_peers.find_one({"username": username})
        return (res["ip"], res["port"])

    def get_online_users(self):
        projection = {'_id': 0, 'username': 1}
        return list(self.db.online_peers.find({}, projection))

    def list_online_users(self):
        online_users = []  # List to store online users
        for user in online_users:
            if user.isOnline:  # Check if user is online
                online_users.append(user.username)  # Add online user to the list
        return online_users
